-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 15 feb 2021 om 14:27
-- Serverversie: 10.4.14-MariaDB
-- PHP-versie: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `examen3`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `houses`
--

CREATE TABLE `houses` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `price` decimal(20,0) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Gegevens worden geëxporteerd voor tabel `houses`
--

INSERT INTO `houses` (`id`, `username`, `name`, `place`, `price`, `created_at`) VALUES
(17, 'Hello', 'Scouting', 'Maassluis', '57778', '2021-02-15 09:22:20'),
(18, 'Hello', 'Scouting', 'Maassluis', '5000', '2021-02-15 09:32:52'),
(19, 'Marjolein', 'Olmendal 88', 'Maassluis', '500000', '2021-02-15 10:54:40'),
(20, 'Hello3', 'Huis is Narnia', 'Narnia', '99999', '2021-02-15 12:02:06'),
(21, 'Hello3', 'ScoutingMakkers', '123', '5000', '2021-02-15 12:04:19'),
(22, 'Judi', 'Vincent ', 'Vlaardingen ', '367000', '2021-02-15 12:08:53'),
(23, 'Judi', 'Sophie', 'Schiedam', '246000', '2021-02-15 12:10:18'),
(24, 'Judi', 'Ben', 'Bennekom', '475000', '2021-02-15 12:12:48'),
(25, 'Judi', 'Ed', 'Ede', '675000', '2021-02-15 12:14:35'),
(26, 'Judi', 'Maud', 'Moodrecht', '563000', '2021-02-15 12:15:07'),
(27, 'Judi', 'Miep', 'Middelburg', '749000', '2021-02-15 12:18:13'),
(28, 'Judi', 'Sara', 'Schaijk', '578000', '2021-02-15 12:20:07'),
(29, 'Judi', 'Zep', 'Zeeland', '310000', '2021-02-15 12:20:41'),
(30, 'noraa', 'tulpje', 'heeze', '100000', '2021-02-15 12:50:07'),
(31, 'noraa', 'ster', 'gilze', '65000', '2021-02-15 12:50:45'),
(32, 'noraa', 'keukenmachine ', 'loenen', '75000', '2021-02-15 12:52:09'),
(33, 'noraa', 'loempia', 'maasluis', '80000', '2021-02-15 12:52:39'),
(34, 'chantal', 'turtle palace', 'timboektoe', '256000', '2021-02-15 13:26:18'),
(35, 'chantal', 'poranian', 'glariana', '8000000', '2021-02-15 13:27:20');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf32;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(2, 'Hello', '$2y$10$bm4t.Nh2TOzPsRYet200ZOaduxMzf1vQEfsJWxGEaLiEqhsgBRg3a', '2021-02-13 22:09:01'),
(5, 'Hello3', '$2y$10$DsCvSJvFxGvuyDfMa3MnZu7rk8tZxBFNq3dugSpfV/D5Mx6spjZJe', '2021-02-15 10:02:19'),
(6, 'Marjolein', '$2y$10$MyPuT1qZm1fgKqi4/bybHu0liwk3blAlHZ89WPSjRrVQTcEUW.ieG', '2021-02-15 10:53:57'),
(7, 'Judi', '$2y$10$HEmxtLhcaHGyl32eUVGKAuewW0iCZHI51KgHjQl5HE07kE7au3.um', '2021-02-15 12:07:18'),
(8, 'nora', '$2y$10$FraKHuhYUEe./ddwzQnsS./n4dtt8iA7VKlgpF3kr4cQ/TO90e3Ri', '2021-02-15 12:48:38'),
(9, 'noraa', '$2y$10$eU91SNN7It7/96gu4IV6ZOANXUlsvZOJm0OrOGC6xAXCKYUjINzKG', '2021-02-15 12:49:23'),
(10, 'chantal', '$2y$10$67amC6ox1qiE28BTmjN/VOACSBPieVREfFd28yMLV25qexTf/W2sO', '2021-02-15 13:23:41');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `houses`
--
ALTER TABLE `houses`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `houses`
--
ALTER TABLE `houses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
